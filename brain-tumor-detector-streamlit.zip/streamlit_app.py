import streamlit as st
from inference_sdk import InferenceHTTPClient
import os

CLIENT = InferenceHTTPClient(
    api_url="https://serverless.roboflow.com",
    api_key="PPOn3zoc59OqaXFYyDrZ"
)

st.title("Brain Tumor Detector")
st.write("Upload an MRI scan of the brain to check for tumor predictions.")

uploaded_file = st.file_uploader("Choose an image...", type=["jpg", "jpeg", "png"])

if uploaded_file is not None:
    with open(uploaded_file.name, "wb") as f:
        f.write(uploaded_file.getbuffer())

    st.image(uploaded_file, caption="Uploaded MRI Scan", use_column_width=True)
    st.write("Analyzing...")

    try:
        result = CLIENT.infer(uploaded_file.name, model_id="my-first-project-tm3fw/1")
        st.subheader("Prediction Result")
        st.json(result)
        os.remove(uploaded_file.name)
    except Exception as e:
        st.error(f"Error: {e}")
        os.remove(uploaded_file.name)